import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MyServiceService } from '../my-service.service';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-slot',
  templateUrl: './slot.component.html',
  styleUrls: ['./slot.component.css']
})
export class SlotComponent implements OnInit {
  slots: any[] = [];

  constructor(private http: HttpClient, private service: MyServiceService) { }

  ngOnInit(): void {
    // Load initial slots
    this.getSlots();
  }

  getSlots() {
    // Call your service method to fetch slots
    this.service.GetSlot().subscribe((response: any) => {
      // Assuming the response contains an array of slots
      this.slots = response;
    }, (error: any) => {
      console.error('Error fetching slots:', error);
    });
  }
}